public class Rectangle{

  private int width;
  private int height;
  
  public Rectangle(rWidth, rHeight)
  {
    width = rWidth;
    height = rHeight;
  }
  
  public String toString()
  {
    return "Rectangle with width " + width + " and height " + height;
  }
  
}
